package org.example;

import com.slack.api.Slack;
import com.slack.api.methods.MethodsClient;
import com.slack.api.methods.SlackApiException;
import com.slack.api.methods.request.chat.ChatPostMessageRequest;
import com.slack.api.methods.response.chat.ChatPostMessageResponse;

import java.io.IOException;

public class App 
{
    public static void main( String[] args ) throws SlackApiException, IOException {

        Slack slack = Slack.getInstance();
        MethodsClient methods = slack.methods("xoxb-2292476206067-2293976530710-tVe7VQzYJ1Ke2SXjipjOzw4g");

        ChatPostMessageRequest request = ChatPostMessageRequest.builder()
                .channel("#random")
                .text(":wave: Hi from a bot written in Java again!")
                .build();

        ChatPostMessageResponse response = methods.chatPostMessage(request);
    }


}
